"""
Local YouTube Downloader — school project tool
------------------------------------------------
Paste a video or playlist link, choose a resolution (or MP3-only audio),
and download it to your computer using yt-dlp. Includes a Dashboard tab
showing your download folder and history.

Requirements (install once):
    pip install -r requirements.txt
    Install ffmpeg and make sure it's on your system PATH
        - Windows: https://www.gyan.dev/ffmpeg/builds/ (get the "essentials" build,
          unzip, add the /bin folder to PATH)
        - Mac:     brew install ffmpeg
        - Linux:   sudo apt install ffmpeg

Run:
    python youtube_downloader.py

To create a Desktop icon that launches this app, run once:
    python create_desktop_shortcut.py

Note: Only download content you have the right to download (your own videos,
Creative Commons content, or things you own). Respect YouTube's Terms of Service.
"""

import os
import platform
import subprocess
import threading
import datetime
import json
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    import yt_dlp
except ImportError:
    raise SystemExit("yt-dlp is not installed. Run:  pip install -r requirements.txt")


# ----------------------------- Config / paths ----------------------------- #

APP_DIR = os.path.dirname(os.path.abspath(__file__))
HISTORY_FILE = os.path.join(APP_DIR, "download_history.json")
SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
DEFAULT_DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "Downloads", "YT Downloads")

RESOLUTION_LABELS = {
    "MP3 (audio only)": "mp3",
    "360p": 360,
    "480p (SD)": 480,
    "720p (HD)": 720,
    "1080p (Full HD)": 1080,
    "1440p (2K)": 1440,
    "2160p (4K / Ultra HD)": 2160,
}


# ----------------------------- Persistence helpers ----------------------------- #

def load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return default
    return default


def save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def load_settings():
    settings = load_json(SETTINGS_FILE, {"download_dir": DEFAULT_DOWNLOAD_DIR})
    os.makedirs(settings["download_dir"], exist_ok=True)
    return settings


def load_history():
    return load_json(HISTORY_FILE, [])


def add_history_entry(title, fmt, save_path):
    history = load_history()
    history.insert(0, {
        "title": title,
        "format": fmt,
        "path": save_path,
        "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
    })
    history = history[:100]  # keep last 100
    save_json(HISTORY_FILE, history)
    return history


def open_folder_in_explorer(path):
    os.makedirs(path, exist_ok=True)
    system = platform.system()
    if system == "Windows":
        os.startfile(path)  # noqa
    elif system == "Darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


# ----------------------------- Core download logic ----------------------------- #

def build_ydl_opts(choice_key, download_dir, is_playlist, progress_hook):
    common = {
        "outtmpl": os.path.join(download_dir, "%(title)s.%(ext)s"),
        "noplaylist": not is_playlist,
        "progress_hooks": [progress_hook],
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": True,  # skip broken items in a playlist instead of stopping
    }

    if choice_key == "mp3":
        common.update({
            "format": "bestaudio/best",
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
        })
    else:
        height = RESOLUTION_LABELS[choice_key]
        common.update({
            "format": f"bestvideo[height<={height}]+bestaudio/best[height<={height}]",
            "merge_output_format": "mp4",
        })

    return common


# ----------------------------- GUI ----------------------------- #

class DownloaderApp:
    def __init__(self, root):
        self.root = root
        root.title("Local YouTube Downloader")
        root.geometry("620x520")
        root.resizable(False, False)

        self.settings = load_settings()
        self.download_dir = self.settings["download_dir"]

        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True, padx=8, pady=8)

        self.download_tab = tk.Frame(notebook)
        self.dashboard_tab = tk.Frame(notebook)
        notebook.add(self.download_tab, text="Download")
        notebook.add(self.dashboard_tab, text="Dashboard")

        notebook.bind("<<NotebookTabChanged>>", lambda e: self.refresh_dashboard())

        self.build_download_tab()
        self.build_dashboard_tab()

    # ---------- Download tab ---------- #
    def build_download_tab(self):
        f = self.download_tab
        pad = {"padx": 10, "pady": 6}

        tk.Label(f, text="Video / Playlist URL:").pack(anchor="w", **pad)
        self.url_entry = tk.Entry(f, width=74)
        self.url_entry.pack(**pad)

        self.playlist_var = tk.BooleanVar(value=False)
        tk.Checkbutton(
            f, text="This is a playlist — download all videos in it",
            variable=self.playlist_var,
        ).pack(anchor="w", **pad)

        tk.Label(f, text="Format / Resolution:").pack(anchor="w", **pad)
        self.format_var = tk.StringVar(value="720p (HD)")
        ttk.Combobox(
            f, textvariable=self.format_var,
            values=list(RESOLUTION_LABELS.keys()),
            state="readonly", width=40,
        ).pack(**pad)

        self.dir_label = tk.Label(f, text=f"Save to: {self.download_dir}", wraplength=580, justify="left")
        self.dir_label.pack(anchor="w", **pad)
        btn_row = tk.Frame(f)
        btn_row.pack(anchor="w", padx=10)
        tk.Button(btn_row, text="Choose Folder", command=self.choose_folder).pack(side="left")
        tk.Button(btn_row, text="Open Folder", command=lambda: open_folder_in_explorer(self.download_dir)).pack(side="left", padx=6)

        self.download_btn = tk.Button(
            f, text="Download", command=self.start_download, bg="#4CAF50", fg="white",
            font=("Arial", 11, "bold")
        )
        self.download_btn.pack(pady=16)

        self.progress = ttk.Progressbar(f, orient="horizontal", length=560, mode="determinate")
        self.progress.pack(pady=6)
        self.status_label = tk.Label(f, text="Idle", wraplength=580, justify="left")
        self.status_label.pack(anchor="w", padx=10)

    def choose_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.download_dir = folder
            self.dir_label.config(text=f"Save to: {self.download_dir}")
            self.settings["download_dir"] = folder
            save_json(SETTINGS_FILE, self.settings)

    def start_download(self):
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showwarning("Missing URL", "Please paste a YouTube link first.")
            return

        self.download_btn.config(state="disabled", text="Downloading...")
        self.progress["value"] = 0
        self.status_label.config(text="Starting...")

        thread = threading.Thread(target=self.run_download, args=(url,), daemon=True)
        thread.start()

    def run_download(self, url):
        choice_key = self.format_var.get()
        resolution_key = "mp3" if choice_key.startswith("MP3") else choice_key
        is_playlist = self.playlist_var.get()
        last_title = {"value": "Unknown title"}

        def progress_hook(d):
            if d["status"] == "downloading":
                pct_str = d.get("_percent_str", "0%").strip().replace("%", "")
                try:
                    pct = float(pct_str)
                except ValueError:
                    pct = 0
                filename = os.path.basename(d.get("filename", ""))
                last_title["value"] = filename
                self.root.after(0, self.update_progress, pct, f"Downloading: {filename} ({pct_str}%)")
            elif d["status"] == "finished":
                self.root.after(0, self.update_progress, 100, "Processing/converting...")

        opts = build_ydl_opts(resolution_key, self.download_dir, is_playlist, progress_hook)

        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                if info:
                    title = info.get("title", last_title["value"])
                    add_history_entry(title, choice_key, self.download_dir)
            self.root.after(0, self.download_finished, True, "Done! Check your download folder.")
        except Exception as e:
            self.root.after(0, self.download_finished, False, f"Error: {e}")

    def update_progress(self, pct, message):
        self.progress["value"] = pct
        self.status_label.config(text=message)

    def download_finished(self, success, message):
        self.status_label.config(text=message)
        self.download_btn.config(state="normal", text="Download")
        if success:
            messagebox.showinfo("Finished", message)
        else:
            messagebox.showerror("Error", message)

    # ---------- Dashboard tab ---------- #
    def build_dashboard_tab(self):
        f = self.dashboard_tab
        pad = {"padx": 10, "pady": 6}

        tk.Label(f, text="Download location:", font=("Arial", 10, "bold")).pack(anchor="w", **pad)
        self.dash_dir_label = tk.Label(f, text=self.download_dir, wraplength=580, justify="left", fg="#333")
        self.dash_dir_label.pack(anchor="w", padx=10)
        tk.Button(f, text="Open Download Folder", command=lambda: open_folder_in_explorer(self.download_dir)).pack(anchor="w", padx=10, pady=6)

        tk.Label(f, text="Recent downloads:", font=("Arial", 10, "bold")).pack(anchor="w", **pad)

        columns = ("title", "format", "date")
        self.history_tree = ttk.Treeview(f, columns=columns, show="headings", height=14)
        self.history_tree.heading("title", text="Title")
        self.history_tree.heading("format", text="Format")
        self.history_tree.heading("date", text="Date")
        self.history_tree.column("title", width=340)
        self.history_tree.column("format", width=140)
        self.history_tree.column("date", width=120)
        self.history_tree.pack(fill="both", expand=True, padx=10, pady=6)

        tk.Button(f, text="Refresh", command=self.refresh_dashboard).pack(anchor="e", padx=10, pady=4)

        self.refresh_dashboard()

    def refresh_dashboard(self):
        self.dash_dir_label.config(text=self.download_dir)
        for row in self.history_tree.get_children():
            self.history_tree.delete(row)
        for entry in load_history():
            self.history_tree.insert("", "end", values=(entry["title"], entry["format"], entry["date"]))


if __name__ == "__main__":
    root = tk.Tk()
    app = DownloaderApp(root)
    root.mainloop()
