# Local YouTube Downloader (School Project)

A desktop app (Python + Tkinter) with two tabs:

**Download tab**
- Paste a YouTube video or playlist link
- Choose a resolution: 360p, 480p, 720p (HD), 1080p (Full HD), 1440p (2K), 2160p (4K/Ultra HD)
- Or choose **MP3 (audio only)** to extract just the audio
- Download an entire playlist by checking the playlist box
- Choose / open your save folder

**Dashboard tab**
- Shows your current download location, with a button to open it directly in File Explorer / Finder
- Shows a history of everything you've downloaded (title, format, date)

Plus a script to create a **Desktop icon** so you can just double-click to open the app.

## 1. Install requirements

You need **Python 3.8+**, **pip**, and **ffmpeg**.

```bash
pip install -r requirements.txt
```

### Install ffmpeg
- **Windows:** download a build from https://www.gyan.dev/ffmpeg/builds/ ("essentials" zip), unzip it, and add the `bin` folder inside it to your system PATH.
- **Mac:** `brew install ffmpeg`
- **Linux (Debian/Ubuntu):** `sudo apt install ffmpeg`

Check it worked:
```bash
ffmpeg -version
```

## 2. Run the app (first time, from VS Code or terminal)

```bash
python youtube_downloader.py
```

## 3. Create a Desktop icon (run this once)

```bash
python create_desktop_shortcut.py
```

This creates a launcher on your Desktop:
- **Windows:** `YouTube Downloader.lnk` (proper shortcut with icon, if `pywin32` is installed — it's in requirements.txt) or a `.bat` file as a fallback.
- **Mac:** `YouTube Downloader.command` — first time, right-click it and choose "Open" to bypass the Gatekeeper warning.
- **Linux:** `youtube-downloader.desktop` — right-click it after and choose "Allow Launching" / "Trust" if it won't open directly.

After this, just double-click the icon on your Desktop any time you want to open the app — no need to open VS Code or a terminal again.

## 4. How to use it

1. Paste the video (or playlist) URL into the text box.
2. If it's a playlist and you want every video in it, check "This is a playlist".
3. Pick a resolution, or select "MP3 (audio only)" for just audio.
4. Click "Choose Folder" to pick where files are saved (remembered for next time), or "Open Folder" to see what's already there.
5. Click "Download" and watch the progress bar.
6. Switch to the **Dashboard** tab any time to see your download folder and history.

## Notes

- If a chosen resolution isn't available for a specific video, yt-dlp automatically falls back to the closest available quality.
- For playlists, if one video fails, the app skips it and keeps going with the rest.
- Your chosen download folder and history are saved automatically in `settings.json` and `download_history.json` next to the app — safe to delete either file to reset.
- **Please use responsibly:** only download videos you have the right to download (your own content, Creative Commons–licensed videos, or material you own). Downloading copyrighted videos may violate YouTube's Terms of Service depending on how you use them.
